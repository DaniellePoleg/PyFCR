import pyfcr

if __name__ == "__main__":
    assert pyfcr.__version__ == "1.0", f"Version: {pyfcr.__version__}"
